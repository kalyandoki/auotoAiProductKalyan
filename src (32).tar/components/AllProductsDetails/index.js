import './index.css'

const AllProductsDetails = props => {
  const {userProductDetails} = props
  const {
    title,
    price,
    description,
    category,
    image,
    rating,
  } = userProductDetails

  const onImgBtn = () => {
    console.log('click')
  }

  return (
    <div className="main-container">
      <div className="container">
        <button type="button" className="btnImg" onClick={onImgBtn}>
          <img className="img-size" src={image} alt={category} />
        </button>
        <div>
          <h1 className="title">{title}</h1>
          <p className="price">Price: {price}</p>
          <p className="description">Description: {description}</p>
          <p className="category">Category: {category}</p>
          <h1 className="rating">Rating</h1>
          <p>Rate: {rating.rate}</p>
          <p>Count: {rating.count}</p>
        </div>
      </div>
    </div>
  )
}

export default AllProductsDetails
