import {Component} from 'react'

import AllProductsDetails from './components/AllProductsDetails'
import './App.css'

class Products extends Component {
  state = {
    productsList: [],
  }

  componentDidMount() {
    this.getProductData()
  }

  getProductData = async () => {
    const response = await fetch('https://fakestoreapi.com/products')
    const data = await response.json()
    console.log(data)
    this.setState({productsList: data})
  }

  render() {
    const {productsList} = this.state
    return (
      <div>
        <h1 className="head">All Products</h1>
        <div>
          <ul className="main-container">
            {productsList.map(eachProduct => (
              <AllProductsDetails
                userProductDetails={eachProduct}
                key={eachProduct.id}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default Products
